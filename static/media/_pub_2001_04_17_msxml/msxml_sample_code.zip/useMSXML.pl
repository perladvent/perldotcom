#!C:\Perl\bin -w

###########################################################################
#
#  Creating an OLE instance of MSXML.DOMDocument
#
###########################################################################


use Win32::OLE qw(in with);
use strict;

my $DOM_document = Win32::OLE->new('MSXML2.DOMDocument.3.0') or die "couldn't create";


###########################################################################
#
#  Parsing the XML
#
###########################################################################


 $DOM_document->{async} = "False";            # disable asynchrous
 $DOM_document->{validateOnParse} = "True";  # validate
 my $boolean_Load = $DOM_document->Load("toptimes.xml");
 if (!$boolean_Load) 
 {
   die "topten.xml did not load\n";
 }


###########################################################################
#
#  Iterating through the XML Document
#
###########################################################################


my $Top_Ten_Times = $DOM_document->DocumentElement();  # assign the root node
my $Events = $Top_Ten_Times->childNodes();             # all of the root's child nodes

foreach my $Event (in $Events) # make sure you include the 'in'
{
   if ( ($Event->Attributes->getNamedItem("NAME")->{Text} eq "100 Backstroke") ||
        ($Event->Attributes->getNamedItem("NAME")->{Text} eq "100 Butterfly") )

   {
       # print the event name stored in the NAME attribute
        print $Event->Attributes->getNamedItem("NAME")->{Text}, "\n";
        my $Swimmers = $Event->childNodes();    # $Swimmers is now a NodeList collection
        foreach my $Swimmer (in $Swimmers )     # iterate through all swimmers
        {
           print $Swimmer->Attributes->getNamedItem("TIME")->{Text}, "\n";  # print the time
        }
   }
}



###########################################################################
#
#  Transforming the XML
#
###########################################################################



Transform("toptimes.xml", "toptimes.xsl", "newtoptimes.xml");

################################################
sub Transform {
################################################
# Assign the File Names
 my $xml_doc_file     = shift;
 my $stylesheet_file  = shift;
 my $new_xml_doc_file = shift;
 my $boolean_Load;

# Create the three OLE DOM instances
 my $doc_to_transform = Win32::OLE->new('MSXML2.DOMDocument.3.0');  
 my $style_sheet_doc  = Win32::OLE->new('MSXML2.DOMDocument.3.0');
 my $transformed_doc  = Win32::OLE->new('MSXML2.DOMDocument.3.0');

# Load the Top Times document
 $doc_to_transform->{async} = "False";
 $doc_to_transform->{validateOnParse} = "True";
 $boolean_Load = $doc_to_transform->Load("$xml_doc_file");
 if(!$boolean_Load)
 {
     die "The Top Times did not load\n";
 }

# Load the Stylesheet
 $style_sheet_doc->{async} = "False";
 $style_sheet_doc->{validateOnParse} = "True";
 $boolean_Load = $style_sheet_doc->Load($stylesheet_file);
 if(!$boolean_Load)
 {
     die "The Stylesheet did not load\n";
 }

#Perform the transformation and save the resulting DOM object
 $doc_to_transform->transformNodeToObject($style_sheet_doc, $transformed_doc);
 $transformed_doc->save("$new_xml_doc_file");
}



###########################################################################
#
#  Updating the XML Document
#
###########################################################################
my $new_DOM_document = Win32::OLE->new('MSXML2.DOMDocument.3.0'); 
$new_DOM_document->{async} = "False";
$new_DOM_document->{validateOnParse} = "True";
$boolean_Load = $new_DOM_document->Load("newtoptimes.xml");
if(!$boolean_Load)
{
   die "The new Top Times did not load\n";
}
my $Peter_Nodes = $new_DOM_document->selectNodes("TOP_TEN_TIMES/EVENT/SWIM/SWIMMER[. = \"Peter Myers\"]");
foreach my $Peter (in $Peter_Nodes)
{
   $Peter->{nodeTypedValue} = "Peter Meyers"  # update the Value
}
$new_DOM_document->save("newertoptimes.xml"); # save the changes



