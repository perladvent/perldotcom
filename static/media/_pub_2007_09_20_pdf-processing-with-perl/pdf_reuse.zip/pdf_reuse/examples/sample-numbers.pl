 use PDF::Reuse;
 use strict ;
 my $n = 1 ;
 prFile("sample-numbers.pdf");
 while (1) {
    prText(550,40,$n++);
    last unless prSinglePage('sample-letters.pdf');
 } 
 prEnd();
