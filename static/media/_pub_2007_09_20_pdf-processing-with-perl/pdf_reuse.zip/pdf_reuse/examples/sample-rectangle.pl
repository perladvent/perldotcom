 use PDF::Reuse;
 use strict;
 prFile('samples/sample-rectangle.pdf');
 my $x = 40;
 my $y = 50 ;
 my @colors ;
 foreach my $r (0..5) {
    foreach my $g (0..5) {
        foreach my $b (0..5) {
            push (@colors, sprintf("%1.1f %1.1f %1.1f rg\n", $r*0.2,$g*0.2,$b*0.2));
        }
    }
 }
 while (1) {
    if ($x > 500) {
        
        $x = 40; $y += 40;
        if ($y > 750) { $y = 50 ; prPage()  ; }
        last unless @colors;
    }
    my $string = "$x $y 30 30 re\n";  # a rectangle 
    $string   .= shift @colors;
    $string   .= "b\n";                  # fill and stroke
    prAdd($string);                       
    $x += 40 ;
 }
 prEnd();
