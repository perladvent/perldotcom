 use PDF::Reuse;
 use Date::Formatter;
 use strict;
 my $date = Date::Formatter->now();
 $date->createDateFormatter("(DD).(MM). (YYYY)");   
 
 my $n = 1 ;
 my $incr = 14 ;
 my $infile = 'customer.txt';
 prFile("sample-letters.pdf");
 prCompress(1);
 prFont('Arial');
 prForm("sample-letter.pdf");
 open (INFILE, "<$infile") || die "Couldn't open $infile, $!\n aborts!\n";
 while (my $line = <INFILE>)  {    
     my $x = 60;
     my $y = 760;
     my ($first, $last, $street, $zipCode, $city, $country) = split(/,/, $line); 
     last unless $country;
     prPage() if $n++ > 1 ;
     prText($x, $y, "$first $last");
     $y -= $incr;
     prText($x, $y, $street);
     $y -= $incr;
     prText($x, $y, $zipCode);
     prText(($x + 40), $y, $city);
     $y -= $incr;
     prText($x, $y, $country);
     prText(60, 600, "Dear $first $last,");
     prText(400,630, "Berlin, $date");

 }
 prEnd();
 close INFILE;
