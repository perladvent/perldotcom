#!/usr/bin/perl -w
#  Author        : Dr. Detlef Groth dgroth(at)gmx(dot)de
#  Created       : Sat Oct 21 07:14:49 2006
#  Last Modified : <061208.0644>
use strict;
use PDF::Reuse;
prFile("out/resultat.pdf");
prDoc('out/file-1.pdf',1,4);
prDoc('out/file-2.pdf',2,9);
prDoc('out/file-3.pdf',8);
prDoc('out/file-4.pdf');
prEnd;
    
    
    
