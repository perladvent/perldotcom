package Demo;

# -- SOAP::Lite -- guide.soaplite.com -- Copyright (C) 2001 Paul Kulchenko --

sub hi {                     
  return "hello, world";     
}

sub bye {                    
  return "goodbye, cruel world";
}

sub languages {                 
  return ("Perl", "C", "sh");   
}                               

1;