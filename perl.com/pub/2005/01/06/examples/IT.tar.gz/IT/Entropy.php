<?php 
/**
* Computes the entropy of an array of tokens (aka symbols).
*/ 
class Entropy { 
  
  var $tokens      = array(); 
  var $num_events  = 0; 
  var $token_freqs = array(); 
  var $token_probs = array();   
  var $num_tokens  = 0; 
  var $bits        = 0.0; 
  var $maxent      = 0.0;   
  var $ratio       = 0.0;     
  
  function Entropy($tokens) { 
    $this->tokens      = $tokens; 
    $this->num_events  = count($this->tokens); 
    $this->token_freqs = $this->getTokenFrequencies(); 
    $this->num_tokens  = count($this->token_freqs); 
    foreach ($this->token_freqs as $token => $freq) { 
      $this->token_probs[$token]  = $freq / $this->num_events; 
      $entropy += $this->token_probs[$token] * log($this->token_probs[$token], 2);   
    } 
    $this->bits   = -1.0 * $entropy; 
    $this->maxent = log($this->num_tokens, 2);     
    $this->ratio  = $this->bits / $this->maxent;
  } 
  
  function getTokenFrequencies() { 
    for ($i = 0; $i < $this->num_events; $i++)
      $token_freqs[$this->tokens[$i]]++; 
    return $token_freqs; 
  } 
  
} 
?> 