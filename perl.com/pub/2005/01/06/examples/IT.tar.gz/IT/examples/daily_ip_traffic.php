<?php
/** 
* Script reports daily ip traffic. 
*/
require_once "config.php";
require_once PHPMATH . "/IT/ArrayMath.php";
?>
<html>
  <head>
    <title>Monthly IP Traffic Report</title>
  </head>
  <body> 
  <?php
  for($year=2004; $year<=2004; $year++) {
    for($month=9; $month<=12; $month++) {                      
      $start =  date("Y-m-d", mktime(0,0,0,$month,1,$year));
      $end   =  date("Y-m-d", mktime(0,0,0,$month+1,0,$year));                  
      $sql   = " SELECT received, count(ip) AS hits, count(DISTINCT ip) AS visitors ";
      $sql  .= " FROM Webstats "; 
      $sql  .= " WHERE received >= '$start' AND received <= '$end' ";        
      $sql  .= " GROUP BY received "; 
      $res   = &$db->query($sql);
      ?>
      <font size='2'>Daily Visits from <?php echo $start ?> to <?php echo $end ?></font>
      <table border='1' cellpadding='5' cellspacing='0'>
        <tr bgcolor='ffffcc'>
          <td><b>Period</b></td><td><b>Hits</b></td><td><b>Visitors</b></td>
        </tr>      
        <?php
        while ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {         
          $hits[]    = $row['hits'];
          $visits[]  = $row['visitors'];
          echo "<tr>";
          echo "  <td><i>".$row['received']."</i></td>";
          echo "  <td align='right'>".$row['hits']."</td>";
          echo "  <td align='right'>".$row['visitors']."</td>";
          echo "</tr>";
        }
        $total_hits   = array_sum($hits);
        $total_visits = array_sum($visits);
        $am = new ArrayMath;
        $mean_hits    = sprintf("%.2f", $am->mean($hits));
        $mean_visits  = sprintf("%.2f", $am->mean($visits));
        $var_hits     = sprintf("%.2f", $am->variance($hits));        
        $var_visits   = sprintf("%.2f", $am->variance($visits));                
        $stdev_hits   = sprintf("%.2f", $am->stdev($hits));        
        $stdev_visits = sprintf("%.2f", $am->stdev($visits));
        $correlation  = sprintf("%.2f", $am->correlation($hits,$visits));                
        $hits   = array();
        $visits = array();        
        ?>
        <tr>
          <td align='right'><b>Mean</b></td>
          <td align='right'><?php echo $mean_hits ?></td>
          <td align='right'><?php echo $mean_visits ?></td>        
        </td>
        <tr>
          <td align='right'><b>Variance</b></td>
          <td align='right'><?php echo $var_hits ?></td>
          <td align='right'><?php echo $var_visits ?></td>        
        </td>
        <tr>
          <td align='right'><b>Std. Dev.</b></td>
          <td align='right'><?php echo $stdev_hits ?></td>
          <td align='right'><?php echo $stdev_visits ?></td>        
        </td>
        <tr>
          <td align='right'><b>Total</b></td>
          <td align='right'><?php echo $total_hits ?></td>
          <td align='right'><?php echo $total_visits ?></td>        
        </td>
      </table>
      <font size='2'>Pearson R = <?php echo $correlation ?></font>
      <br /><br />
      <?php
      if($year == date("Y")) 
        if($month == date("m")) 
          break(2); 
    }
  }  
  ?> 
  </body>
</html>