<?php

require_once "PEAR.php"; 

class ArrayMath { 

  /** 
  * Determines whether the data object is a matrix 
  * or not.  Used in functions that emulate polymorphic 
  * java methods - if argument is matrix do one set of 
  * operations otherwise do another set.  See sumSquares 
  * method. 
  */ 
  function isMatrix($data) { 
    $slice = $data[0]; 
    return is_array($slice) ? 1 : 0; 
  } 
   
  /** 
  * Renormalizes the array so that its L2 norm is 1 
  * (up to computational errors). 
  */ 
  function normalize($v) { 
    return $this->scalarMultiply(1.0 / $this->norm($v), $v); 
  } 

  /** 
  * Computes the L2 norm of an array (Euclidean norm or "length"). 
  */ 
  function norm($v) { 
    return sqrt($this->sumSquares($v)); 
  } 

  /** 
  * Sums the squares of all components; 
  * also called the energy of the array. 
  */ 
  function sumSquares($data) { 
    if ($this->isMatrix($data)) { 
      $ans = 0; 
      $nRows = count($data); 
      $nCols = count($data[0]); 
      for($i=0; $i < $nRows; $i++) 
        for($j=0; $j < $nCols; $j++)  
          $ans += $data[$i][$j] * $data[$i][$j]; 
    } else { 
      $ans = 0; 
      $len = count($v); 
      for($i = 0; $i < $len; $i++) 
        $ans += $v[$i] * $v[$i]; 
    } 
    return $ans; 
  } 
   
  /** 
  * Computes the variance. 
  */ 
  function variance($v) { 
    $m   = $this->mean($v); 
    $ans = 0.0; 
    $len = count($v); 
    for($i=0; $i < $len; $i++) 
      $ans += pow($v[$i] - $m, 2); 
    return $ans /($len - 1); 
  } 

  /** 
  * Computes the covariance. 
  */ 
  function covariance($v1, $v2) { 
    $len1 = count($v1); 
    $len2 = count($v2); 
    if($len1 != $len2) 
      die("Arrays must have the same length : $len1, $len2"); 
    $m1  = $this->mean($v1); 
    $m2  = $this->mean($v2); 
    $ans = 0.0; 
    for($i=0; $i < $len1; $i++) 
      $ans += ($v1[$i]-$m1) * ($v2[$i]-$m2); 
    return $ans / ($len1 - 1); 
  } 

  /** 
  * Computes the (linear) correlation between two arrays. 
  * Squaring this result and multiply by 100 gives you 
  * the percentage of correlation. 
  */ 
  function correlation($v1, $v2) { 
    $denom = sqrt($this->variance($v1) * $this->variance($v2)); 
    if($denom != 0) 
      return($this->covariance($v1, $v2) / $denom); 
    else { 
      if ( ($this->variance($v1)==0) && ($this->variance($v2)==0) ) 
        return 1.0; 
      else 
        return 0.0;  // impossible to correlate a null signal with another 
    } 
  }     

  /** 
  * Computes the mean. 
  */ 
  function mean($v) { 
    $len = count($v); 
    if ($len==0) 
      die("Nothing to compute! The array must have at least one element."); 
    return $this->mass($v) / $len; 
  } 

  /** 
  * Returns the standard deviation of an array. 
  */ 
  function stdev($v) { 
    return sqrt($this->variance($v)); 
  } 
     
  /** 
  * Returns the sum of the elements of the array. 
  */ 
  function mass($v) { 
    $sum = 0; 
    $len = count($v); 
    for($i=0; $i < $len; $i++)  
      $sum += $v[$i]; 
    return $sum; 
  } 
     
  /** 
  * Multiplies every component of an array by a scalar. 
  */ 
  function scalarMultiply($a, $v) { 
    $ans = array(); 
    for($i=0; $i < $len; $i++) 
      $ans[$i] = $v[$i] * $a; 
    return $ans; 
  } 

  /** 
  * Fast scalar multiplication for sparse arrays. 
  */ 
  function scalarMultiplyFast($a, $v) { 
    $len = count($v); 
    if ($a == 0.0) 
      return count($v); 
    $ans = array();           
    for($i=0; $i < $len; $i++) { 
      if ( ($a!=0) && ($v[$i]!=0) ) 
        $ans[$i] = $v[$i] * $a; 
      else 
        $ans[$i] = 0.0; 
    }         
    for($i=0; $i < $len; $i++) {         
      if ( ($a!=0) && ($v[$i]!=0) ) 
        $ans[$i] = $v[$i] * $a; 
      else 
        $ans[$i] = 0.0; 
    } 
    return $ans; 
  }     
     
  /** 
  * Adds the two arrays together (componentwise). 
  * @exception IllegalArgumentException if the 
  * two arrays don't have the same length. 
  */ 
  function add($a, $b) { 
    $len1 = count($a); 
    $len2 = count($b); 
    if($len1 != $len2) 
      die("Arrays must have the same length : $len1, $len2"); 
    $ans = $a;         
    for($i=0; $i < $len1; $i++) 
      $ans[$i] += $b[$i]; 
    return $ans; 
  } 
   
  /** 
  * Subtracts the two arrays together (componentwise). 
  * @exception IllegalArgumentException if the 
  * two arrays don't have the same length. 
  */ 
  function subtract($a, $b) { 
    $len1 = count($a); 
    $len2 = count($b); 
    if($len1 != $len2) 
      die("Arrays must have the same length : $len1, $len2"); 
    $ans = $a;         
    for($i=0; $i < $len1; $i++) 
      $ans[$i] -= $b[$i]; 
    return $ans; 
  }     
      
} 

?> 