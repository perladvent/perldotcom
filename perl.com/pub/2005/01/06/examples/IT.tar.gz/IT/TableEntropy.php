<?php 
/** 
* Computes the entropy of a database column. 
*/ 
class TableEntropy { 

  var $table       = ""; 
  var $column      = ""; 
  var $select      = "";     
  var $where       = "";   
  var $group_by    = "";     
    
  var $num_events  = 0; 
  var $token_freqs = array(); 
  var $token_probs = array();   
  var $num_tokens  = 0; 
  var $bits        = 0.0; 
  var $maxent      = 0.0;   
  var $ratio       = 0.0;     

  function setTable($table) {
    $this->table = $table;
  }

  function setColumn($column) {
    $this->column = $column;
  }

  function setSelect($sql) {
    $this->select = $sql;
  }

  function setWhere($sql) {
    $this->where = $sql;
  }

  function setGroupBy($sql) {
    $this->group_by = $sql;
  }
  
  function getTokenFrequencies() {
    global $db;            
    $sql  = " SELECT $this->column, count($this->column) as freq ";                   
    $sql .= " FROM ". $this->table;    
    if ($this->where != "") 
      $sql .= " WHERE ". $this->where;    
    if ($this->group_by != "")       
      $sql .= " GROUP BY ". $this->group_by;        
    else 
      $sql .= " GROUP BY ". $this->column;            
    $this->token_freqs = $db->getCol($sql, "freq");
  }
  
  function getEntropy() {
    global $db;     
    $this->getTokenFrequencies();
    $this->num_events  = array_sum($this->token_freqs); 
    $this->num_tokens  = count($this->token_freqs);     
    foreach ($this->token_freqs as $token => $freq) { 
      $this->token_probs[$token]  = $freq / $this->num_events; 
      $entropy += $this->token_probs[$token] * log($this->token_probs[$token], 2);   
    } 
    $this->bits   = -1.0 * $entropy; 
    $this->maxent = log($this->num_tokens, 2);    
    $this->ratio  = $this->bits / $this->maxent;        
  } 

} 
?> 