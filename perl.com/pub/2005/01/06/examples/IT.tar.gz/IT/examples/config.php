<?php
// Define path to root of PHPMATH library.
define("PHPMATH", "/home/php/math");  

// Define MySQL connection string in PEAR:DB format. You will need 
// to set up a database with login parameters and configure this 
// connection string before the database-aware classes will work.
define("MYSQL", "mysql://myuser:mypass@localhost/mydb");

// Set up database connection.
require_once 'DB.php';
$db =& DB::connect(MYSQL);
if (DB::isError($db)) {
  echo 'Standard Message: ' . $db->getMessage() . "<br />";
  echo 'DBMS/User Message: ' . $db->getUserInfo() . "<br />";
  echo 'DBMS/Debug Message: ' . $db->getDebugInfo() . "<br />";
  exit;
}
$db->setFetchMode(DB_FETCHMODE_ASSOC);

// Start a named session.
session_name("entropy");
session_start();
?>
