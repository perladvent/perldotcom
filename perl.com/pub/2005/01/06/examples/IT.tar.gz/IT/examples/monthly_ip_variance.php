<?php
/** 
* Script the reports monthly ip traffic. 
*/
require_once "config.php";
require_once PHPMATH . "/IT/ArrayMath.php";
require_once PHPMATH . "/IT/TableEntropy.php";

$am  = new ArrayMath;

$ent = new TableEntropy;
$ent->setTable("Webstats");
$ent->setColumn("ip");
?>
<html>
  <head>
    <title>Monthly IP Traffic Report</title>
  </head>
  <body> 
  <font size='2'><i>Monthly Variance and Entropy</i></font>
  <table border='1' cellpadding='5' cellspacing='0'>
    <tr bgcolor='ffffcc'>
      <td><b>Period</b></td>
      <td align='center'><b>Hits</b></td>
      <td align='center'><b>Visitors</b></td>
      <td align='center'><b>Entropy</b></td>      
    </tr>      
    <?php
    for($year=2004; $year<=2004; $year++) {
      for($month=1; $month<=12; $month++) {                  
        $start =  date("Y-m-d", mktime(0,0,0,$month,1,$year));
        $end   =  date("Y-m-d", mktime(0,0,0,$month+1,0,$year));   
        // Do stuff to get the entropy
        $clause = " received >= '$start' AND received <= '$end' ";
        $ent->setWhere($clause);
        $ent->getEntropy();              
        $entropy = sprintf("%.2f", $ent->bits);          
        // Now, do stuff to get the variance
        $sql   = " SELECT received, count(ip) AS hits, count(DISTINCT ip) AS visitors ";
        $sql  .= " FROM Webstats "; 
        $sql  .= " WHERE received >= '$start' AND received <= '$end' ";        
        $sql  .= " GROUP BY received "; 
        $res   = &$db->query($sql);
        while ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {         
          $hits[]    = $row['hits'];
          $visits[]  = $row['visitors'];
        }
        $hit_var = sprintf("%.2f", $am->variance($hits));
        $vis_var = sprintf("%.2f", $am->variance($visits));
        ?>
        <tr>
          <td align='right'><i><?php echo "$start to $end"; ?></i></td>
          <td align='right'><?php echo $hit_var ?></td>
          <td align='right'><?php echo $vis_var ?></td>        
          <td align='right'><?php echo $entropy ?></td>                  
        </tr>
        <?php
        $hit_vars[]  = $hit_var;
        $vis_vars[]  = $vis_var;        
        $entropies[] = $entropy;                
        $hits   = array();
        $visits = array();        
        if($year == date("Y")) 
          if($month == date("m")) 
            break(2); 
      }
    }    
    ?>
   </table>
   <?php
   $am = new ArrayMath;
   echo "correlation(hits, visits): ".$am->correlation($hit_vars,$vis_vars)."<br />";
   echo "correlation(hits, entropy): ".$am->correlation($hit_vars,$entropies)."<br />";    
   echo "correlation(visits, entropy): ".$am->correlation($vis_vars,$entropies);  
   ?>     
  </body>
</html>