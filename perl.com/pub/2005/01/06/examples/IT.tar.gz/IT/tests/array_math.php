<?php 

include "../ArrayMath.php";

$am = new ArrayMath(); 

$EOL = "<br />";

$vec1 = array(2, 4, 6, 8); 
$vec2 = array(3, 9, 27, 81); 

echo "<b>vec1</b>";
echo "<pre>";
print_r($vec1);
echo "</pre>";

echo "<b>vec2</b>";
echo "<pre>";
print_r($vec2);
echo "</pre>";

print "mass(vec) - expected 20, actual  ". $am->mass($vec1) . $EOL; 
print "mean(vec) - expected 5, actual  ". $am->mean($vec1) . $EOL;  
print "variance(vec) - expected 6.666, actual  ". $am->variance($vec1) . $EOL; 
print "stdev(vec) - expected  2.581989, actual  ". $am->stdev($vec1) . $EOL; 
print "covariance(vec1, vec2) - expected 84, actual  ". $am->covariance($vec1, $vec2) . $EOL; 
print "correlation(vec1, vec2) - expected 0.9165151, actual  ". $am->correlation($vec1, $vec2) . $EOL; 

?>