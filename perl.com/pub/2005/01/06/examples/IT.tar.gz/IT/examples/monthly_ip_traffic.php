<?php
/** 
* Script the reports monthly ip traffic. 
*/
require_once "config.php";
require_once PHPMATH . "/IT/TableEntropy.php";
require_once PHPMATH . "/IT/ArrayMath.php";
$e = new TableEntropy;
$e->setTable("Webstats");
$e->setColumn("ip");
?>
<html>
  <head>
    <title>Monthly IP Traffic Report</title>
  </head>
  <body> 
    <i>Monthly IP Traffic Report: Hits, Visitors, Entropy</i>
    <table border='1' cellpadding='5' cellspacing='0'>
      <tr bgcolor='ffffcc'>
        <td><b>Period</b></td><td><b>Hits</b></td>
        <td><b>Visitors</b></td><td><b>Entropy</b></td>
        <td><b>MaxEnt</b></td><td><b>Ratio</b></td>
      </tr>      
      <?php
      for($year=2004; $year<=2004; $year++) {
        for($month=1; $month<=12; $month++) {  
          $start  =  date("Y-m-d", mktime(0,0,0,$month,1,$year));
          $end    =  date("Y-m-d", mktime(0,0,0,$month+1,0,$year));        
          $clause = " received >= '$start' AND received <= '$end' ";
          $e->setWhere($clause);
          $e->getEntropy();
          echo "<tr>";
          echo "  <td><i>$start to $end</i></td>";
          echo "  <td align='right'>". $e->num_events ."</td>";
          echo "  <td align='right'>". $e->num_tokens ."</td>";
          echo "  <td align='right'>". sprintf("%01.2f", $e->bits) ."</td>";
          echo "  <td align='right'>". sprintf("%01.2f", $e->maxent) ."</td>";          
          echo "  <td align='right'>". sprintf("%01.2f", $e->ratio) ."</td>";                    
          echo "</tr>";
          if($e->num_events != 0) {
            $hits[]    = $e->num_events;
            $visits[]  = $e->num_tokens;
            $entropy[] = $e->bits;                                         
          }
          if($year == date("Y")) 
            if($month == date("m")) 
              break(2);
        }
      }
      ?>
    </table>
    <?php
    $am = new ArrayMath;
    echo "correlation(hits, visits): ".$am->correlation($hits,$visits)."<br />";
    echo "correlation(hits, entropy): ".$am->correlation($hits,$entropy)."<br />";    
    echo "correlation(visits, entropy): ".$am->correlation($visits,$entropy);  
    ?> 
  </body>
</html>