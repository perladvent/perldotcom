<?php 
/**
* Measures the entropy for a few hypothetical values from a page_id column 
* of a typical Webstats table.  Uses the following abbreviations: h=HomePage, 
* n=NewsPage, p=ProductsPage, s=ServicesPage, a=AboutPage.
*/ 
require_once "../Entropy.php"; 
$tokens = array("h","n","p","s","h","n","h","a","h","p","h","s","h","n","p");                 
$e = new Entropy($tokens); 
?>
<pre>
<?php print_r($e) ?>
</pre>
<p>
The Entropy of the source measured in bits is: <?php echo $e->bits ?> 
</p>