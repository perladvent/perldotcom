<html>
<head>
  <title>IT Package</title>
</head>
<body>

<p>
<h1>IT Package</h1>
</p>

<p>
by Paul Meagher &lt;paul@datavore.com&gt;
</p>

<p>
<?php
$SELF = basename($_SERVER['PHP_SELF']);
if (file_exists($SELF)) 
  echo "<small>Last modified " . date("F d Y @ g:i a T", filemtime($SELF)) ."</small>"; 
?>
</p>

<hr />
Download <a href='../IT.tar.gz'>IT.tar.gz</a>.
<hr />

<p>
Examples:
</p>
<ul>
  <li><a href='../examples/clickstream_entropy.php'>clickstream_entropy.php</a> - Calculate entropy of a sequence of page states.</li>
  <li><a href='../examples/monthly_ip_traffic.php'>monthly_ip_traffic.php</a> - Calculate monthly hits, visitors and entropy from <code>ip</code> column.</li>  
  <li><a href='../examples/monthly_page_traffic.php'>monthly_page_traffic.php</a> - Calculate monthly hits, pages and entropy from <code>self</code> column.</li>      
  <li><a href='../examples/daily_ip_traffic.php'>daily_ip_traffic.php</a> - Calculate daily hits and visits based on the <code>ip</code> column.</li>        
  <li><a href='../examples/monthly_variance_and_entropy.php'>monthly_variance_and_entropy.php</a> - Calculate monthly variance and entropy from <code>ip</code> column.</li>          
</ul>

<a name='listing'>
<p>
Source code listing:
</p>
<ul>
  <li><a href='<?php echo "$SELF?id=0#source"; ?>'>Entropy.php</a></li>
  <li><a href='<?php echo "$SELF?id=1#source"; ?>'>TableEntropy.php</a></li>
  <li><a href='<?php echo "$SELF?id=2#source"; ?>'>ArrayMath.php</a></li>
  <li><a href='<?php echo "$SELF?id=3#source"; ?>'>examples/clickstream_entropy.php</a></li>
  <li><a href='<?php echo "$SELF?id=4#source"; ?>'>examples/monthly_ip_traffic.php</a></li>
  <li><a href='<?php echo "$SELF?id=5#source"; ?>'>examples/monthly_page_traffic.php</a></li>
  <li><a href='<?php echo "$SELF?id=6#source"; ?>'>examples/daily_ip_traffic.php</a></li>
  <li><a href='<?php echo "$SELF?id=7#source"; ?>'>examples/monthly_variance_and_entropy.php</a></li>
  <li><a href='<?php echo "$SELF?id=8#source"; ?>'>tests/array_math.php</a></li>
  <li>examples/config.php</li>    
</ul>

<a name='source'>
<?php
if (isset($_GET["id"])) {
  ?>
  <hr />
  <br />
  <?php
  switch($_GET["id"]) {
    case 0:
      highlight_file("../Entropy.php");
      break;
    case 1:
      highlight_file("../TableEntropy.php");
      break;
    case 2:
      highlight_file("../ArrayMath.php");
      break;
    case 3:
      highlight_file("../examples/clickstream_entropy.php");
      break;
    case 4:
      highlight_file("../examples/monthly_ip_traffic.php");
      break;
    case 5:
      highlight_file("../examples/monthly_page_traffic.php");
      break;
    case 6:
      highlight_file("../examples/daily_ip_traffic.php");
      break;
    case 7:
      highlight_file("../examples/monthly_ip_variance.php");
      break;
    case 8:
      highlight_file("../tests/array_math.php");
      break;
  }
  ?>
  <br />
  <hr />
  <br />
  << <a href='<?php echo "$SELF?id=$id#listing"; ?>'>Source code listing</a>
  <?php
}
?>    
</body>
</html>