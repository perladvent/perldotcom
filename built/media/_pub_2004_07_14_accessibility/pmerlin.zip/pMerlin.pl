#!/usr/bin/perl
#######################################################################
# The main script
use strict;
use warnings;

my $obj = pMerlin->new();
$obj->MainLoop;

#######################################################################
# The pMerlin package, the Wx::App subclass...
#
package pMerlin;
use Wx;
use base 'Wx::App';

sub OnInit
{
    my $self = shift;

    # Set the App- and Vendor name
    $self->SetAppName('Fun With Merlin');
    $self->SetVendorName("pVoice Applications - Jouke Visser");
    # Set the device we use to 'icon' (mousebuttons)
    my $config = Wx::ConfigBase::Get;
    my $Device = $config->Read('Device', 'icon');
    $config->Write('Device',   $Device);
    # Create the frame
    my $frame = pMerlinFrame->new( undef, -1, 'pMerlin');
    # And show it
    $frame->Show(1);
}

#######################################################################
# The pMerlinFrame, where the actual stuff happens
#
package pMerlinFrame;
use Wx qw(:everything);
use base 'Wx::Frame';
use AAC::Pvoice;
use Win32::MSAgent;


sub new
{
    my $class = shift;
    # Call the superclass' constructor
    my $self = $class->SUPER::new(@_);
    
    # The frame's background
    $self->SetBackgroundColour(wxWHITE);
    
    #--------------------------------------------------------------------------
    # Initialize the MS Agent stuff
    #--------------------------------------------------------------------------

    $self->{agent} = Win32::MSAgent->new();
    $self->{agent}->Characters->Load('Merlin', "merlin.acs");
    # To be able to access the character from $self's
    # action methods, we have to define it as a property of that
    $self->{char} = $self->{agent}->Characters('Merlin');
    # Set Language to US English
    $self->{char}->LanguageID(0x409);
    # Select the Heather US English voice from BrightSpeech
    $self->{char}->TTSModeID("{e3c16dbc-7c19-4f2b-95BE-9DBFA94F9D4B}");

    $self->Move(0,0);    
    # Show the MS Agent
    $self->{char}->Show();

    #--------------------------------------------------------------------------
    # End of the MS Agent initialization
    #--------------------------------------------------------------------------

    # Get the dimensions of the maximized window
    $self->Show(1);
    $self->Maximize(1);
    my ($width, $height) = ($self->GetClientSize->GetWidth,
                            $self->GetClientSize->GetHeight);
    $self->Show(0);
    
    # define the margin
    my $margin = 20;
    
    # define the itemspacing
    my $itemspacing = 4;

    # And create a pVoice panel
    $self->{panel} = AAC::Pvoice::Panel->new($self,              # parent
                                             -1,                 # id
                                             [$margin, $margin], # position
                                             [$width-2*$margin, $height-2*$margin],
                                                                 # size
                                             wxNO_3D,            # style
                                             1,                  # hide textrow
                                             $itemspacing,       # spacing between items
                                             3);                 # selectionborderwidth
    # The grey background for the panel
    my $panelbackground = Wx::Colour->new(220,220,220);
    $self->{panel}->BackgroundColour($panelbackground);

    # A title at the top of the panel
    $self->{panel}->AddTitle("Fun with Merlin");

    # The maximum dimensions of a button
    my $maxX = int(($self->{panel}->xsize)/4)-2*$itemspacing;
    my $maxY = int(($self->{panel}->ysize)/3)-2*$itemspacing; 

    # Define the bitmaps
    my $leftbutton     = AAC::Pvoice::Bitmap->new('img/left.png',     $maxX, $maxY, 'left');
    my $rightbutton    = AAC::Pvoice::Bitmap->new('img/right.png',    $maxX, $maxY, 'right');
    my $upbutton       = AAC::Pvoice::Bitmap->new('img/up.png',       $maxX, $maxY, 'up');
    my $downbutton     = AAC::Pvoice::Bitmap->new('img/down.png',     $maxX, $maxY, 'down');
    my $questionbutton = AAC::Pvoice::Bitmap->new('img/question.png', $maxX, $maxY, 'question');
    my $rowselbutton   = AAC::Pvoice::Bitmap->new('img/rowsel.png',   $maxX, $maxY, 'rowsel');

    # Define the buttons on the pVoice rows
    my $left     = [Wx::NewId(), $leftbutton,    sub {$self->MoveLeft}];
    my $right    = [Wx::NewId(), $rightbutton,   sub {$self->MoveRight}];
    my $up       = [Wx::NewId(), $upbutton,      sub {$self->MoveUp}];
    my $down     = [Wx::NewId(), $downbutton,    sub {$self->MoveDown}];
    my $question = [Wx::NewId(), $questionbutton,sub {$self->Speak}];
    my $rowsel   = [Wx::NewId(), $rowselbutton,  sub {$self->{panel}->ToRowSelection}];

    # The definition of the screenlayout
    my $content = [ [ $rowsel,    undef,    $up,       undef  ],
                    [ $rowsel,    $left,    $question, $right ],
                    [ $rowsel,    undef,    $down,     undef  ] ];

    # Add the buttons to the rows and the rows to the panel
    foreach my $row (@$content)
    {
        $self->{panel}->Append(AAC::Pvoice::Row->new($self->{panel},     # parent
                                                     scalar(@$row),      # max
                                                     $row,               # items
                                                     wxDefaultPosition,  # pos
                                                     wxDefaultSize,      # size
                                                     $maxX,              # X-size
                                                     $maxY,              # Y-size
                                                     $itemspacing,       # spacing
                                                     $panelbackground)); # background
    }
    # Finish the panel
    $self->{panel}->Finalize();

    # and return
    return $self;
}

sub Speak
{
    my $self = shift;
    $self->{char}->Speak("See how easy it is to create Accessible software?");
}

sub Move
{
    my $self = shift;
    @{$self->{position}} = @_[0,1];
    $self->{char}->MoveTo(@{$self->{position}});
}

sub MoveUp
{
    my $self = shift;
    $self->{position}->[1] = 0 
        if $self->{position}->[1] > 0;
    $self->Move(@{$self->{position}});
}

sub MoveDown
{
    my $self = shift;
    $self->{position}->[1] = $self->{panel}->ysize - 50 
        if $self->{position}->[1] < $self->{panel}->ysize - 50;
    $self->Move(@{$self->{position}});
}

sub MoveLeft
{
    my $self = shift;
    $self->{position}->[0] = 0 
        if $self->{position}->[0] > 0;
    $self->Move(@{$self->{position}});
}

sub MoveRight
{
    my $self = shift;
    $self->{position}->[0] = $self->{panel}->xsize - 50 
        if $self->{position}->[0] < $self->{panel}->xsize - 50;
    $self->Move(@{$self->{position}});
}

