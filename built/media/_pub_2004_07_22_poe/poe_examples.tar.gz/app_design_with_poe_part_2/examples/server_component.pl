#!/usr/bin/perl

use warnings;
use strict;

use lib qw(lib ../lib);

use POE;
use POE::Filter::SimpleQueryString;
use POE::Component::Server::TCP;

POE::Component::Server::TCP->new(
    Address => '127.0.0.1',
    Port    => '31337',

    ClientFilter => "POE::Filter::SimpleQueryString",
    ClientInput => sub {
        my $input = $_[ARG0];
        use Data::Dumper;
        print Dumper $input;

        $_[HEAP]->{client}->put($input);
    }
);

POE::Kernel->run();

