#!/usr/bin/perl

use warnings;
use strict;

use lib qw(lib ../lib);

use POE;
use POE::Component::SimpleQueryString;

POE::Component::SimpleQueryString->new(
    ListenAddr => '127.0.0.1',
    ListenPort    => '31337',

    InputEvent => sub {
        my $input = $_[ARG0];
        use Data::Dumper;
        print Dumper $input;

        $_[HEAP]->{client}->put($input);
    }
);

POE::Kernel->run();

