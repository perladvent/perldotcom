#!/usr/bin/perl

use warnings;
use strict;

use lib qw(lib ../lib);

use POE;
use POE::Filter::SimpleQueryString;
use POE::Driver::SysRW;
use POE::Wheel::SocketFactory;
use POE::Wheel::ReadWrite;

POE::Session->create(
    inline_states => {
        _start          => \&start,
        factory_success => \&factory_success,
        
        client_input    => \&client_input,
        client_error    => \&client_error,

        fatal_error     => sub { die "A fatal error occurred" },
        _stop           => sub {},
    },
);

POE::Kernel->run();


sub start {
    $_[HEAP]->{factory} = POE::Wheel::SocketFactory->new(
        BindAddress     => '127.0.0.1',
        BindPort        => '31337',
        SuccessEvent    => 'factory_success',
        FailureEvent    => 'fatal_error',
        SocketProtocol  => 'tcp',
        Reuse           => 'on',
    );
}


sub factory_success {
    my $handle = $_[ARG0];
        
    my $wheel = POE::Wheel::ReadWrite->new(
            Handle      => $handle,
            Driver      => POE::Driver::SysRW->new(),
            Filter      => POE::Filter::SimpleQueryString->new(),
            InputEvent  => 'client_input',
    );

    $_[HEAP]->{clients}->{ $wheel->ID } = $wheel;
}

sub client_input {
    my ($input, $wheel_id) = @_[ARG0, ARG1];

    use Data::Dumper;
    print Dumper $input;

    $_[HEAP]->{clients}->{ $wheel_id }->put( $input );
}

