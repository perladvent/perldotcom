package POE::Filter::SimpleQueryString;

use warnings;
use strict;

our $VERSION = '1.'.sprintf "%04d", (qw($Rev: 384 $))[1];

use Carp qw(carp croak);

sub new { 
    my $class = shift;
    my $self = bless {}, $class;
    return $self;
}

sub get {
    my $self = shift;
    my $buffer = shift;
 
    my @chunks; 
  
    foreach my $record (@$buffer) { 
        $record =~ s/\x0d\x0a$//;

        my @pairs = split(/&/, $record);
    
        my %chunk;

        foreach my $pair (@pairs) {
            my ($key, $value) = split(/=/,$pair,2);
        
            if(defined $chunk{$key}) {
                if(ref $chunk{$key} eq 'ARRAY') {
                    push @{ $chunk{$key} }, $value;
                } else {
                    $chunk{$key} = [ $chunk{$key}, $value ],
                }
            } else {
                $chunk{$key} = $value;
            }
        }
        push @chunks, \%chunk;
    }
    return \@chunks;
}

sub put { 
    my $self = shift;
    my $records = shift;

    my @raw;
    
    foreach my $record (@$records) {
        my @chunks;
        foreach my $key (sort keys %$record) {
            if(ref $record->{$key}) {
                if(ref $record->{$key} eq 'ARRAY') {
                    foreach my $value ( @{ $record->{$key} } ) {
                        push @chunks, $key."=".$value;
                    }
                } else {
                    carp __PACKAGE__." cannot handle data of type ".ref $record->{$key};
                }
            } else {
                push @chunks, $key."=".$record->{$key};
            }
        }
        push @raw, join('&',@chunks)."\x0d\x0a";
    }
    return \@raw;
}
1;
__END__

=pod

=head1 NAME

POE::Filter::SimpleQueryString - example POE Filter

=head1 SYNOPSIS

This module is part of a perl.com article on application design with poe.

=head1 AUTHOR

Matt Cashner (sungo@pobox.com)

=head1 DATE

$Date: 2004-07-20 15:55:59 -0400 (Tue, 20 Jul 2004) $

=head1 LICENSE

Copyright (c) 2004, Matt Cashner. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

=over 4

=item * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.  

=item * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

=item * Neither the name of the Matt Cashner nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

=back

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

=cut

