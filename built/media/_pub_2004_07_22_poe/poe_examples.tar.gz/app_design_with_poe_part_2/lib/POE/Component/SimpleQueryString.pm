package POE::Component::SimpleQueryString;

use warnings;
use strict;

use POE;
use POE::Component::Server::TCP;

use POE::Filter::SimpleQueryString;

use Carp qw(croak carp);

our $VERSION = '1.'.sprintf "%04d", (qw($Rev: 377 $))[1];

sub new {
    my $class = shift;
    my %args = @_;

    my $addr = delete $args{ListenAddr} || croak "ListenAddr required";
    my $port = delete $args{ListenPort} || croak "ListenPort required";
    my $input_event = delete $args{InputEvent} || croak "InputEvent required";
    my $alias = delete $args{Alias} || __PACKAGE__;

    my $server = POE::Component::Server::TCP->new(
                    Address => $addr,
                    Port => $port,
                    Alias => $alias,

                    ClientInput => $input_event,
                    ClientFilter => "POE::Filter::SimpleQueryString",
                 );
    
    return $server;
}

1;
__END__

=pod

=head1 NAME

POE::Component::SimpleQueryString - example POE Component

=head1 SYNOPSIS

This module is part of a perl.com article on application design with poe.

=head1 AUTHOR

Matt Cashner (sungo@pobox.com)

=head1 DATE

$Date$

=head1 LICENSE

Copyright (c) 2004, Matt Cashner. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

=over 4

=item * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.  

=item * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

=item * Neither the name of the Matt Cashner nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

=back

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

=cut

