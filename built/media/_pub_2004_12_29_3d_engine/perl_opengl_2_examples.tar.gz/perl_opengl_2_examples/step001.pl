#!/usr/bin/perl

use strict;
use warnings;
use SDL::App;
use SDL::OpenGL;

my ($done, $frame);
my ($conf, $sdl_app);

START: main();


sub main
{
    init();
    main_loop();
    cleanup();
}

sub init
{
    $| = 1;
    init_conf();
    init_window();
}

sub init_conf
{
    $conf = {
        title  => 'Camel 3D',
        width  => 400,
        height => 400,
    };
}

sub init_window
{
    my ($title, $w, $h) = @$conf{qw( title width height )};

    $sdl_app = SDL::App->new(-title  => $title,
                             -width  => $w,
                             -height => $h,
                             -gl     => 1,
                            );
    SDL::ShowCursor(0);
}

sub main_loop
{
    while (not $done) {
        $frame++;
        do_frame();
    }
}

sub do_frame
{
    prep_frame();
    draw_frame();
    end_frame();
}

sub prep_frame
{
    glClear(GL_COLOR_BUFFER_BIT);
}

sub draw_frame
{
    print '.';
    sleep 1;
    $done = 1 if $frame == 5;
}

sub end_frame
{
    $sdl_app->sync;
}

sub cleanup
{
    print "\nDone.\n"
}
