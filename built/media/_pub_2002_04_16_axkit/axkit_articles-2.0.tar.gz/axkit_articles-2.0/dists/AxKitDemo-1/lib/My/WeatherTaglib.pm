package My::WeatherTaglib;

$NS = "http://slaysys.com/axkit_articles/weather/";
@EXPORT_TAGLIB = ( 'report($zip)', 'query($zip)' );

## Work around a bug in 1.5.1
@ISA = qw( Apache::AxKit::Language::XSP::TaglibHelper );

sub parse_char  { Apache::AxKit::Language::XSP::TaglibHelper::parse_char(@_)  }
sub parse_start { Apache::AxKit::Language::XSP::TaglibHelper::parse_start(@_) }
sub parse_end   { Apache::AxKit::Language::XSP::TaglibHelper::parse_end(@_)   }
## End workaround

use strict;
use Apache::AxKit::Language::XSP::TaglibHelper;
use Geo::Weather;

## Return the whole report for fixup later in the processing pipeline
sub report { Geo::Weather->new->get_weather( @_ ) }

1;
